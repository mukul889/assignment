Steps to run code
1. Please paste code in your golang path
2. Off your go module to run the code. 
3. have updated the url path to run the code in postman

-- I have understanding in GOLANG REST API so i made the assignment in REST API.
If you given me chance to learn GRPC then I happly learn at your workspace.