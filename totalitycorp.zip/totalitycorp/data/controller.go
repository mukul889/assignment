package data

import (
	"encoding/json"
	"fmt"
	"net/http"

	"github.com/julienschmidt/httprouter"
)

//AllUsers
func AllUsers(w http.ResponseWriter, r *http.Request, _ httprouter.Params) {

	allUsers := GetAllUsers()
	JsonResponse(w, allUsers)
}

//GetUser
func GetUser(w http.ResponseWriter, r *http.Request, p httprouter.Params) {
	userID := p.ByName("userid")
	userInfo := GetUserData(userID)
	JsonResponse(w, userInfo)
}

//GetUserData
func GetUserData(userID string) User {

	var user User
	var marriedStatus int
	err := DbConn.QueryRow("SELECT id, first_name,city,phone,height,married_status FROM users WHERE id ", userID).Scan(&user.Id,
		&user.Name,
		&user.City,
		&user.Phone,
		&user.Height,
		&marriedStatus)
	if err != nil {
		fmt.Println(err)
	}

	if marriedStatus == 1 {
		user.Married = true
	}

	return user
}

func GetAllUsers() []User {
	var allUsers []User

	rows, err := DbConn.Query("SELECT id, first_name,city,phone,height,married_status FROM users ")
	if err != nil {
		fmt.Println(err)
	}

	for rows.Next() {

		var user User
		var marriedStatus int
		err := rows.Scan(
			&user.Id,
			&user.Name,
			&user.City,
			&user.Phone,
			&user.Height,
			&marriedStatus,
		)

		if err != nil {
			fmt.Println(err)
		}
		if marriedStatus == 1 {
			user.Married = true
		}

		allUsers = append(allUsers, user)
	}
	return allUsers
}
func JsonResponse(w http.ResponseWriter, response interface{}) {
	w.Header().Set("Containt-type", "application/json")

	json.NewEncoder(w).Encode(response)
}
