package data

import (
	"database/sql"
)

var DbConn *sql.DB

func ConnectionDB(servername, username, password string) (*sql.DB, error) {
	var err error
	DbConn, err = sql.Open("mysql", username+password+"@tcp("+servername+")/tempdb")

	if err != nil {
		return DbConn, err
	}

	return DbConn, nil
}
