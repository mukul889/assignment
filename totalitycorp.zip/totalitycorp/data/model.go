package data

type OutPut struct {
	users interface{} `json:"Users"`
}
type User struct {
	Id      int32   `json:"id,omitempty"`
	Name    string  `json:"fname,omitempty"`
	City    string  `json:"city,omitempty"`
	Phone   int64   `json:"phone,omitempty"`
	Height  float64 `json:"height,omitempty"`
	Married bool    `json:"Married,omitempty"`
}
