package main

import (
	"fmt"
	"github.com/julienschmidt/httprouter"
	"github.com/totalitycorp/data"
	"log"
	"net/http"
)

func main() {

	fmt.Println("Assignment started!")
	// mysql DB setup //
	server := "localhost"
	port := "3306"
	pass := ""
	_, err := data.ConnectionDB(server, port, pass)
	if err != nil {
		panic(err)
	}
	routes()
}

func routes() {
	route := httprouter.New()
	route.GET("/users", data.AllUsers)
	route.POST("/get-user/:userid", data.GetUser)
	log.Fatal(http.ListenAndServe("8000", route))
}
